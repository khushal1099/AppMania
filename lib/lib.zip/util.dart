List<Map> productList = [
  {
    "image":"images/1.jpeg",
    "name": "Avocada salad",
    "price": "           \$12.00",
    "rating": "☆ 4.5",
    "time": "20 min",
  },
  {
    "image":"images/fruit-salad.jpg",
    "name": "Fruits salad",
    "price": "           \$11.00",
    "rating":  "☆ 4.2",
    "time": "15 min",
  },
];
List<Map> productList1 = [
  {
    "image":"images/cucumber-salad.jpg",
    "name": "Cucumber salads",
    "price": "           \$11.50",
    "rating":  "☆ 4.1",
    "time": "15 min",
  },
  {
    "image":"images/avocado-cucumber-salad-.jpg",
    "name": "Special salad",
    "price": "           \$13.00",
    "rating":  "☆ 4.2",
    "time": "25 min",
  },
];
List<Map> cartlist=[];