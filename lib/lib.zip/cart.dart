import 'package:appmania/util.dart';
import 'package:flutter/material.dart';

class cart extends StatefulWidget {
  const cart({super.key});

  @override
  State<cart> createState() => _cartState();
}

class _cartState extends State<cart> {
  var size = 1;
  double total = 0;

  @override
  Widget build(BuildContext context) {
    total = 0;
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        actions: [
          Icon(
            Icons.close,
            color: Colors.white,
          )
        ],
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: Text("Cart"),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [ Stack(children: [
              Container(child: Image.asset("images/background.jpeg")),
              Container(
                height: 800,
                margin: EdgeInsets.only(top: 190),
                decoration: const BoxDecoration(
                    color: Colors.white70,
                    borderRadius:
                        BorderRadius.vertical(top: Radius.circular(20)),
                    boxShadow: [
                      BoxShadow(
                          color: Colors.grey,
                          offset: Offset(0, -8),
                          blurRadius: 10),
                    ]),
                child: Column(
                  children: [
                    Stack(children: [
                      Container(
                        margin: EdgeInsets.all(10),
                        height: 95,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                      Row(
                        children: cartlist.map((e) {
                          return Container(
                            clipBehavior: Clip.antiAlias,
                            margin: EdgeInsets.only(top: 28, left: 20),
                            height: 70,
                            width: 70,
                            decoration: BoxDecoration(
                                color: Colors.grey, shape: BoxShape.circle),
                            child: Image.asset(
                              e["image"],
                              fit: BoxFit.cover,
                            ),
                          );
                          // Padding(
                          // padding: const EdgeInsets.only(top: 20, left: 10),
                          // child: Text(
                          // e["name"],
                          // style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                          // ),
                          // ),
                          // Stack(children: [
                          // Padding(
                          // padding: const EdgeInsets.only(left: 25, top: 25),
                          // child: InkWell(
                          // onTap: () {
                          // setState(() {
                          // if (size > 0) {
                          // size = size - 1;
                          // }
                          // });
                          // },
                          // child: Icon(
                          // Icons.remove_circle_rounded,
                          // size: 35,
                          // ),
                          // ),
                          // ),
                          // Padding(
                          // padding: const EdgeInsets.only(top: 28, left: 60),
                          // child: Text(
                          // " $size",
                          // style: TextStyle(
                          // fontSize: 25, fontWeight: FontWeight.bold),
                          // ),
                          // ),
                          // Padding(
                          // padding: const EdgeInsets.only(left: 83, top: 25),
                          // child: InkWell(
                          // onTap: () {
                          // setState(() {
                          // size = size + 1;
                          // });
                          // },
                          // child: Icon(
                          // Icons.add_circle,
                          // size: 35,
                          // ),
                          // ),
                          // ),
                          // Padding(
                          // padding: const EdgeInsets.only(left: 40, top: 68),
                          // child: Text(
                          // e["price"],
                          // style:
                          // TextStyle(fontSize: 20, color: Colors.grey),
                          // ),
                          // ),
                          // ]);
                        }).toList(),

                      ),
                      Text("hello")
                    ]),
                    Stack(children: [
                      // Container(
                      //   margin: EdgeInsets.all(10),
                      //   height: 70,
                      //   decoration: BoxDecoration(
                      //     borderRadius: BorderRadius.circular(10),
                      //     color: Colors.white,
                      //   ),
                      // ),
                    //   Row(
                    //     children: [
                    //       Container(
                    //         margin: EdgeInsets.only(top: 15, left: 20),
                    //         height: 60,
                    //         width: 60,
                    //         decoration: BoxDecoration(
                    //             //color: Colors.white, shape: BoxShape.circle
                    //             ),
                    //         child: Image.asset(
                    //           'images/coupon.png',
                    //           color: Colors.grey,
                    //         ),
                    //       ),
                    //       Container(
                    //         margin: EdgeInsets.only(left: 20, top: 13),
                    //         child: Text(
                    //           'promo code',
                    //           style:
                    //               TextStyle(fontSize: 25, color: Colors.grey),
                    //         ),
                    //       ),
                    //       Container(
                    //         height: 40,
                    //         width: 80,
                    //         margin: EdgeInsets.only(left: 50, top: 15),
                    //         child: Center(
                    //           child: Text(
                    //             'Apply',
                    //             style: TextStyle(
                    //                 fontSize: 20, color: Colors.white),
                    //           ),
                    //         ),
                    //         decoration: BoxDecoration(
                    //             color: Colors.green,
                    //             borderRadius: BorderRadius.circular(20),
                    //             boxShadow: [
                    //               BoxShadow(blurRadius: 10, color: Colors.green)
                    //             ]),
                    //       ),
                    //     ],
                    //   )
                    // ]),
                    // Stack(children: [
                    //   Container(
                    //     margin: EdgeInsets.only(top: 30),
                    //     height: 330,
                    //     decoration: BoxDecoration(
                    //       borderRadius: BorderRadius.circular(10),
                    //       color: Colors.white,
                    //     ),
                    //   ),
                    //   Container(
                    //     margin: EdgeInsets.only(right: 30, left: 30),
                    //     decoration: BoxDecoration(
                    //         border: Border(
                    //             bottom:
                    //                 BorderSide(color: Colors.grey, width: 1))),
                    //     child: Row(
                    //       mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    //       children: [
                    //         Container(
                    //           margin: EdgeInsets.only(top: 100),
                    //           child: Text(
                    //             'Subtotal',
                    //             style: TextStyle(fontSize: 25),
                    //           ),
                    //         ),
                    //         Container(
                    //           margin: EdgeInsets.only(top: 100, left: 20),
                    //           child: Text('\$70.00',
                    //               style: TextStyle(fontSize: 20)),
                    //         ),
                    //       ],
                    //     ),
                    //   ),
                    //   Container(
                    //     margin: EdgeInsets.only(right: 30, left: 30, top: 43),
                    //     decoration: BoxDecoration(
                    //         border: Border(
                    //             bottom:
                    //                 BorderSide(color: Colors.grey, width: 1))),
                    //     child: Row(
                    //       mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    //       children: [
                    //         Container(
                    //           margin: EdgeInsets.only(top: 100),
                    //           child: Text(
                    //             'Delivery',
                    //             style: TextStyle(fontSize: 25),
                    //           ),
                    //         ),
                    //         Container(
                    //           margin: EdgeInsets.only(top: 100, left: 20),
                    //           child: Text("\$70.00",
                    //               style: TextStyle(fontSize: 20)),
                    //         ),
                    //       ],
                    //     ),
                    //   ),
                    //   Container(
                    //     margin: EdgeInsets.only(right: 30, left: 30, top: 80),
                    //     decoration: BoxDecoration(
                    //         border: Border(
                    //             bottom:
                    //                 BorderSide(color: Colors.grey, width: 1))),
                    //     child: Row(
                    //       mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    //       children: [
                    //         Container(
                    //           margin: EdgeInsets.only(top: 100),
                    //           child: Text(
                    //             'Total',
                    //             style: TextStyle(
                    //                 fontSize: 25, fontWeight: FontWeight.bold),
                    //           ),
                    //         ),
                    //         Container(
                    //           margin: EdgeInsets.only(top: 100, left: 20),
                    //           child: Text('\$ $total',
                    //               style: TextStyle(
                    //                   fontSize: 25,
                    //                   fontWeight: FontWeight.bold)),
                    //         ),
                    //       ],
                    //     ),
                    //   ),
                    //   Container(
                    //     height: 60,
                    //     width: 300,
                    //     margin: EdgeInsets.only(left: 50, top: 250),
                    //     child: Center(
                    //       child: Text(
                    //         'CHECKOUT',
                    //         style: TextStyle(fontSize: 20, color: Colors.white),
                    //       ),
                    //     ),
                    //     decoration: BoxDecoration(
                    //         color: Colors.green,
                    //         borderRadius: BorderRadius.circular(10),
                    //         boxShadow: [
                    //           BoxShadow(blurRadius: 10, color: Colors.green)
                    //         ]),
                    //   ),
                    ]),
                  ],
                ),
              ),
            ]),
    ],
        ),
      ),
    );
  }
}
